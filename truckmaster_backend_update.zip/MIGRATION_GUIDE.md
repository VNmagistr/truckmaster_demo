# 🔄 Інструкція з міграції бази даних TruckMaster

## Огляд змін

### Нові додатки:
- `users` — користувачі з ролями
- `maintenance` — історія обслуговування

### Оновлені додатки:
- `inventory` — додано категорії, склади, рух товарів

---

## ⚠️ ВАЖЛИВО: Зробіть бекап!

```bash
# На сервері
pg_dump -U postgres truckmaster > backup_$(date +%Y%m%d_%H%M%S).sql

# або для SQLite
cp db.sqlite3 db_backup_$(date +%Y%m%d).sqlite3
```

---

## Крок 1: Створення нових додатків

```bash
cd /path/to/your/project

# Створіть нові додатки
python manage.py startapp users
python manage.py startapp maintenance
```

## Крок 2: Копіювання файлів моделей

Замініть/створіть файли:

```
your_project/
├── users/
│   ├── __init__.py
│   ├── models.py          ← з пакету
│   ├── admin.py           ← створити
│   └── apps.py
├── maintenance/
│   ├── __init__.py
│   ├── models.py          ← з пакету
│   ├── admin.py           ← створити
│   └── apps.py
├── inventory/
│   ├── models.py          ← ЗАМІНИТИ з пакету
│   └── fixtures/
│       └── initial_categories.json  ← з пакету
```

## Крок 3: Оновлення settings.py

```python
# settings.py

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    
    # Third party
    'rest_framework',
    'corsheaders',
    
    # Local apps
    'users',          # ← ДОДАТИ (перед іншими)
    'clients',
    'inventory',
    'orders',
    'maintenance',    # ← ДОДАТИ
    'bot',
]

# Кастомна модель користувача
AUTH_USER_MODEL = 'users.User'
```

## Крок 4: Оновлення apps.py

### users/apps.py
```python
from django.apps import AppConfig

class UsersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'users'
    verbose_name = 'Користувачі'
```

### maintenance/apps.py
```python
from django.apps import AppConfig

class MaintenanceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'maintenance'
    verbose_name = 'Обслуговування'
```

## Крок 5: Створення адмін-панелі

### users/admin.py
```python
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User, UserActionLog

@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = ['username', 'email', 'first_name', 'last_name', 'role', 'is_active']
    list_filter = ['role', 'is_active', 'is_staff']
    fieldsets = BaseUserAdmin.fieldsets + (
        ('Додатково', {'fields': ('role', 'phone', 'position', 'warehouses')}),
    )
    add_fieldsets = BaseUserAdmin.add_fieldsets + (
        ('Додатково', {'fields': ('role', 'phone')}),
    )
    filter_horizontal = ['warehouses', 'groups', 'user_permissions']

@admin.register(UserActionLog)
class UserActionLogAdmin(admin.ModelAdmin):
    list_display = ['user', 'action_type', 'model_name', 'created_at']
    list_filter = ['action_type', 'model_name', 'created_at']
    readonly_fields = ['user', 'action_type', 'model_name', 'object_id', 
                       'object_repr', 'changes', 'ip_address', 'created_at']
```

### maintenance/admin.py
```python
from django.contrib import admin
from .models import FluidChangeRecord, ServiceReminder, TruckFluidSpec

@admin.register(FluidChangeRecord)
class FluidChangeRecordAdmin(admin.ModelAdmin):
    list_display = ['truck', 'subcategory', 'product', 'quantity', 'mileage', 'performed_at']
    list_filter = ['subcategory', 'performed_at']
    search_fields = ['truck__license_plate', 'truck__last_seven_vin']
    date_hierarchy = 'performed_at'

@admin.register(ServiceReminder)
class ServiceReminderAdmin(admin.ModelAdmin):
    list_display = ['truck', 'title', 'status', 'priority', 'target_date', 'target_mileage']
    list_filter = ['status', 'priority', 'subcategory']
    search_fields = ['truck__license_plate', 'title']

@admin.register(TruckFluidSpec)
class TruckFluidSpecAdmin(admin.ModelAdmin):
    list_display = ['truck', 'subcategory', 'recommended_product', 'fill_volume']
    list_filter = ['subcategory']
    search_fields = ['truck__license_plate']
    filter_horizontal = ['alternative_products']
```

### inventory/admin.py (оновити)
```python
from django.contrib import admin
from .models import (
    ProductCategory, ProductSubcategory, 
    Warehouse, Part, Stock, StockMovement,
    PartCategory, UsedPart
)

@admin.register(ProductCategory)
class ProductCategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'category_type', 'sort_order', 'is_active']
    list_filter = ['category_type', 'is_active']
    prepopulated_fields = {'slug': ('name',)}

@admin.register(ProductSubcategory)
class ProductSubcategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'category', 'default_change_interval_km', 'is_active']
    list_filter = ['category', 'is_active']
    prepopulated_fields = {'slug': ('name',)}

@admin.register(Warehouse)
class WarehouseAdmin(admin.ModelAdmin):
    list_display = ['name', 'is_default', 'is_active', 'sort_order']
    list_filter = ['is_active', 'is_default']
    prepopulated_fields = {'slug': ('name',)}

@admin.register(Part)
class PartAdmin(admin.ModelAdmin):
    list_display = ['name', 'brand', 'sku_code', 'subcategory', 'selling_price', 'current_stock']
    list_filter = ['subcategory__category', 'subcategory', 'brand', 'is_active']
    search_fields = ['name', 'sku_code', 'brand']
    filter_horizontal = ['substitutes']

@admin.register(Stock)
class StockAdmin(admin.ModelAdmin):
    list_display = ['product', 'warehouse', 'quantity', 'reserved', 'available', 'is_low_stock']
    list_filter = ['warehouse']
    search_fields = ['product__name', 'product__sku_code']

@admin.register(StockMovement)
class StockMovementAdmin(admin.ModelAdmin):
    list_display = ['product', 'movement_type', 'quantity', 'warehouse_from', 'warehouse_to', 'created_at']
    list_filter = ['movement_type', 'warehouse_from', 'warehouse_to', 'created_at']
    search_fields = ['product__name', 'invoice_number']
    date_hierarchy = 'created_at'

# Існуючі (залишаємо)
@admin.register(PartCategory)
class PartCategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'parent']

@admin.register(UsedPart)
class UsedPartAdmin(admin.ModelAdmin):
    list_display = ['part', 'service_work', 'quantity', 'warehouse']
```

## Крок 6: Міграції

```bash
# Спершу створіть міграції для users (бо інші моделі від нього залежать)
python manage.py makemigrations users

# Потім для інших
python manage.py makemigrations inventory
python manage.py makemigrations maintenance

# Перевірте міграції
python manage.py showmigrations

# Застосуйте міграції
python manage.py migrate
```

### ⚠️ Можлива помилка з AUTH_USER_MODEL

Якщо вже є користувачі в базі, потрібно:

1. **Варіант А: Скинути базу** (якщо дані не критичні)
```bash
python manage.py flush
python manage.py migrate
python manage.py createsuperuser
```

2. **Варіант Б: Міграція існуючих користувачів**
Створіть data migration:
```bash
python manage.py makemigrations users --empty --name migrate_users
```

І в файлі міграції:
```python
def migrate_users(apps, schema_editor):
    OldUser = apps.get_model('auth', 'User')
    NewUser = apps.get_model('users', 'User')
    
    for old_user in OldUser.objects.all():
        NewUser.objects.create(
            id=old_user.id,
            username=old_user.username,
            email=old_user.email,
            password=old_user.password,
            # ... інші поля
            role='admin' if old_user.is_superuser else 'mechanic'
        )
```

## Крок 7: Завантаження початкових даних

```bash
python manage.py loaddata initial_categories
```

## Крок 8: Перевірка

```bash
# Запустіть сервер
python manage.py runserver

# Перевірте адмінку
# http://localhost:8000/admin/
```

---

## 📋 Чек-лист після міграції

- [ ] База даних оновлена без помилок
- [ ] Адмінка відкривається
- [ ] Категорії товарів створені (Оливи, Фільтри, Рідини, Омивачі)
- [ ] Склади створені (Головний, Задній, Митний)
- [ ] Існуючі товари (Part) доступні
- [ ] Можна створити нового користувача з роллю
- [ ] API працює (якщо є)

---

## 🔙 Відкат (якщо щось пішло не так)

```bash
# Відновити базу з бекапу
psql -U postgres truckmaster < backup_YYYYMMDD_HHMMSS.sql

# Видалити міграції
rm users/migrations/0*.py
rm maintenance/migrations/0*.py

# Видалити додатки з INSTALLED_APPS
# Закоментувати AUTH_USER_MODEL
```

---

## Наступні кроки

Після успішної міграції:
1. Налаштувати API endpoints (Django REST Framework)
2. Оновити фронтенд для нових функцій
3. Мігрувати існуючі товари в нові категорії
